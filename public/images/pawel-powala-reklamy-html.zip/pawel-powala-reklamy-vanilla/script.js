/* =========================================================
   PAWEŁ POWAŁA REKLAMY — script.js
   Czysty JavaScript, bez bibliotek zewnętrznych.
   Kod uruchamia się dopiero, gdy cała strona (DOM) jest gotowa.
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

  /* ---------------------------------------------------------
     1) MENU MOBILNE — otwieranie / zamykanie
     --------------------------------------------------------- */
  const navToggle = document.getElementById("navToggle");
  const navMenu = document.getElementById("navMenu");

  function openMenu() {
    navMenu.classList.add("is-open");
    navToggle.setAttribute("aria-expanded", "true");
    navToggle.setAttribute("aria-label", "Zamknij menu");
  }

  function closeMenu() {
    navMenu.classList.remove("is-open");
    navToggle.setAttribute("aria-expanded", "false");
    navToggle.setAttribute("aria-label", "Otwórz menu");
  }

  navToggle.addEventListener("click", function () {
    const isOpen = navMenu.classList.contains("is-open");
    if (isOpen) {
      closeMenu();
    } else {
      openMenu();
    }
  });

  /* ---------------------------------------------------------
     2) ZAMYKANIE MENU PO KLIKNIĘCIU LINKU
     (przydatne na telefonie, po wybraniu sekcji)
     --------------------------------------------------------- */
  const navLinks = navMenu.querySelectorAll("a");
  navLinks.forEach(function (link) {
    link.addEventListener("click", function () {
      closeMenu();
    });
  });

  /* ---------------------------------------------------------
     3) PŁYNNE PRZEWIJANIE DO SEKCJI
     Uwaga: w style.css ustawione jest już "scroll-behavior: smooth",
     więc zwykłe linki #kotwica działają płynnie same z siebie.
     Ten kod jest dodatkowym zabezpieczeniem dla starszych przeglądarek
     i pozwala poprawnie obsłużyć wysokość przyklejonego navbaru.
     --------------------------------------------------------- */
  const anchorLinks = document.querySelectorAll('a[href^="#"]');
  anchorLinks.forEach(function (link) {
    link.addEventListener("click", function (event) {
      const targetId = link.getAttribute("href");
      if (targetId.length > 1) {
        const targetEl = document.querySelector(targetId);
        if (targetEl) {
          event.preventDefault();
          targetEl.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      }
    });
  });

  /* ---------------------------------------------------------
     4) i 5) LIGHTBOX GALERII (otwieranie, zamykanie, Escape)
     --------------------------------------------------------- */
  const lightbox = document.getElementById("lightbox");
  const lightboxImage = document.getElementById("lightboxImage");
  const lightboxClose = document.getElementById("lightboxClose");
  const galleryButtons = document.querySelectorAll(".gallery__button");

  function openLightbox(imageSrc, imageAlt) {
    lightboxImage.src = imageSrc;
    lightboxImage.alt = imageAlt;
    lightbox.classList.add("is-open");
    lightbox.setAttribute("aria-hidden", "false");
  }

  function closeLightbox() {
    lightbox.classList.remove("is-open");
    lightbox.setAttribute("aria-hidden", "true");
    // Czyścimy src, żeby przeglądarka nie trzymała niepotrzebnie dużego obrazu w pamięci
    lightboxImage.src = "";
  }

  galleryButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      const fullSrc = button.getAttribute("data-full");
      const altText = button.getAttribute("data-alt");
      openLightbox(fullSrc, altText);
    });
  });

  // Zamknięcie przyciskiem "X"
  lightboxClose.addEventListener("click", closeLightbox);

  // Zamknięcie po kliknięciu w ciemne tło (poza zdjęciem)
  lightbox.addEventListener("click", function (event) {
    if (event.target === lightbox) {
      closeLightbox();
    }
  });

  // Zamknięcie klawiszem Escape
  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && lightbox.classList.contains("is-open")) {
      closeLightbox();
    }
  });

  /* ---------------------------------------------------------
     6) i 7) WALIDACJA FORMULARZA I KOMUNIKAT PO WYSŁANIU
     --------------------------------------------------------- */
  const contactForm = document.getElementById("contactForm");
  const formSuccess = document.getElementById("formSuccess");

  const nameInput = document.getElementById("name");
  const contactInput = document.getElementById("contactInfo");
  const messageInput = document.getElementById("message");

  const nameError = document.getElementById("nameError");
  const contactError = document.getElementById("contactError");
  const messageError = document.getElementById("messageError");

  contactForm.addEventListener("submit", function (event) {
    // Zatrzymujemy domyślne przeładowanie strony przez formularz
    event.preventDefault();

    // Resetujemy poprzednie komunikaty błędów
    nameError.textContent = "";
    contactError.textContent = "";
    messageError.textContent = "";
    formSuccess.textContent = "";

    let isValid = true;

    if (nameInput.value.trim() === "") {
      nameError.textContent = "Podaj imię i nazwisko.";
      isValid = false;
    }

    if (contactInput.value.trim() === "") {
      contactError.textContent = "Podaj numer telefonu lub adres e-mail.";
      isValid = false;
    }

    if (messageInput.value.trim() === "") {
      messageError.textContent = "Napisz krótką wiadomość.";
      isValid = false;
    }

    if (!isValid) {
      return;
    }

    /* -----------------------------------------------------
       MIEJSCE NA PODŁĄCZENIE PRAWDZIWEJ WYSYŁKI WIADOMOŚCI
       -----------------------------------------------------
       Obecnie formularz nie wysyła danych na żaden serwer.
       Aby to zmienić, można na przykład:
       1) Wysłać dane przez fetch() do własnego API:
            fetch("https://twoj-serwer.pl/api/kontakt", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                name: nameInput.value,
                contact: contactInput.value,
                message: messageInput.value,
              }),
            });
       2) Skorzystać z gotowej usługi formularzy, np. Formspree
          (https://formspree.io) — wystarczy dodać odpowiedni
          atrybut "action" do znacznika <form> w index.html.
       ----------------------------------------------------- */

    // Pokazujemy komunikat potwierdzający wysłanie
    formSuccess.textContent =
      "Dziękujemy za wiadomość. Skontaktujemy się z Tobą.";

    // Czyścimy formularz po poprawnym wysłaniu
    contactForm.reset();
  });

  /* ---------------------------------------------------------
     8) AKTUALNY ROK W STOPCE
     --------------------------------------------------------- */
  const currentYearEl = document.getElementById("currentYear");
  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }

  /* ---------------------------------------------------------
     9) DELIKATNA ANIMACJA ELEMENTÓW PRZY PRZEWIJANIU
     (IntersectionObserver — element dostaje klasę "is-visible",
     gdy pojawi się w widocznym obszarze ekranu)
     --------------------------------------------------------- */
  const revealElements = document.querySelectorAll(".reveal");

  if ("IntersectionObserver" in window && revealElements.length > 0) {
    const revealObserver = new IntersectionObserver(
      function (entries, observer) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            // Element animujemy tylko raz - potem przestajemy go obserwować
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    revealElements.forEach(function (el) {
      revealObserver.observe(el);
    });
  } else {
    // Jeśli przeglądarka nie wspiera IntersectionObserver,
    // po prostu pokazujemy wszystkie elementy od razu.
    revealElements.forEach(function (el) {
      el.classList.add("is-visible");
    });
  }

});
